# 🛍️ ShopZone — Angular 19 E-Commerce App

A full-featured Angular 19 e-commerce application with dark mode, filtering, auth, admin dashboard and CRUD operations.

---

## ⚡ Quick Start

```bash
# 1. Install dependencies
npm install

# 2. Run the app
ng serve

# 3. Open browser
# http://localhost:4200
```

---

## 🗂️ Project Structure

```
src/
├── app/
│   ├── components/
│   │   ├── header/          ← Sticky nav, dark toggle, cart badge
│   │   ├── home/            ← Hero, features, featured products
│   │   ├── shop/            ← Products list with all filters
│   │   ├── product-card/    ← Reusable card component
│   │   ├── product-detail/  ← Single product page
│   │   ├── cart/            ← Shopping cart page
│   │   ├── login/           ← Login form
│   │   ├── register/        ← Register form
│   │   ├── dashboard/       ← Admin-only CRUD panel
│   │   ├── about/           ← About page
│   │   └── contact/         ← Contact form
│   ├── services/
│   │   ├── theme.service.ts    ← Dark/light mode (Signal)
│   │   ├── auth.service.ts     ← Login / Register / Logout
│   │   ├── product.service.ts  ← CRUD for products
│   │   └── cart.service.ts     ← Cart state
│   ├── models/
│   │   ├── product.model.ts
│   │   ├── user.model.ts
│   │   └── cart.model.ts
│   ├── guards/
│   │   └── auth.guard.ts       ← adminGuard + authGuard
│   ├── app.ts                  ← Root component
│   ├── app.routes.ts           ← All routes
│   └── app.config.ts           ← App config
└── styles.css                  ← Global CSS variables (theme)
```

---

## ✨ Features Explained (Simply)

### 1. 🔍 Filter by Name
**Where:** `/shop` page sidebar  
**How it works:** Type anything in the search box. The product list instantly updates to show only products whose name or description matches what you typed. Uses Angular's `signal()` and `computed()` so it's reactive — no button click needed.

### 2. 💰 Filter by Price
**Where:** `/shop` page sidebar  
**How it works:** Two range sliders: one for minimum price, one for maximum. Drag them to set a price range. Only products within your range are shown. Combined with the search and category filters.

### 3. 📂 Filter by Category
**Where:** `/shop` page sidebar  
**How it works:** Buttons for All, Electronics, Sports, Fashion, Kitchen. Click one to show only that category. Active button is highlighted in primary color.

### 4. ↕️ Sort Products
**Where:** `/shop` page sidebar dropdown  
**Options:** Default / Price Low→High / Price High→Low / Name A→Z / Top Rated

### 5. 🔗 Navigation (Header links)
- **Home** → Goes to `/` (main landing page)
- **Shop** → Goes to `/shop` (product listing)
- **About** → Goes to `/about`
- **Contact** → Goes to `/contact`
- **🔍 Search icon** → Goes to `/shop` (search there)
- **🛒 Cart icon** → Goes to `/cart` with live item count badge
- **Dashboard** → Only visible to admin users, goes to `/dashboard`

### 6. 📦 Dynamic Data + CRUD Operations
All product data is stored in `localStorage` (persists across page refreshes).

**CRUD = Create, Read, Update, Delete:**
- **Create** → Admin clicks "+ Add Product" in dashboard and fills the form
- **Read** → Products shown in shop, home, and dashboard table
- **Update** → Admin clicks "Edit" next to a product, changes values, saves
- **Delete** → Admin clicks "Delete" then confirms in the popup

### 7. 👤 User Roles: Admin vs User
Two types of accounts:

| Role  | What they can do                              |
|-------|-----------------------------------------------|
| user  | Browse, filter, add to cart, view orders      |
| admin | Everything + access to Dashboard (CRUD panel) |

**Demo credentials:**
- **Admin:** `admin@shop.com` / `admin123`
- **User:** `user@shop.com` / `user123`

You can also **register** a new account (always gets `user` role).

### 8. 🛡️ Guard — Dashboard Protection
The `/dashboard` route is protected by `adminGuard`.  
- If you're not logged in → redirected to `/login`
- If you're logged in but NOT admin → redirected to `/login`
- Only logged-in admins can see and use the dashboard

The "Dashboard" link in the navbar is also hidden from non-admin users.

### 9. 🌙 Dark Mode (Signal-based)
Click the 🌙/☀️ button in the header to toggle dark/light mode.

**How it works using Angular Signals:**
```typescript
// In ThemeService:
isDark = signal<boolean>(false);  // the signal

// Using effect() to auto-update DOM:
effect(() => {
  document.body.setAttribute('data-theme', this.isDark() ? 'dark' : 'light');
  localStorage.setItem('theme', ...);  // saves preference
});

// Toggle:
toggle() { this.isDark.set(!this.isDark()); }
```

The theme is **saved to localStorage**, so it persists when you refresh the page. CSS variables (`--bg`, `--text`, `--card-bg`, etc.) automatically switch based on `data-theme` attribute on `<body>`.

### 10. 🛒 Shopping Cart
- Add products from the shop or product detail page
- Cart icon in header shows live count badge
- Cart page shows: items, quantities, subtotal, shipping, total
- Update quantity with +/− buttons
- Remove individual items or clear entire cart
- Shipping is free for orders over $50

---

## 🧠 How Angular Signals Are Used

Signals are Angular's modern reactive state system (no RxJS needed for simple state).

```typescript
// Creating a signal
count = signal(0);

// Reading it
count()  // → 0

// Updating it
count.set(5);
count.update(n => n + 1);

// computed() = derived value (auto-updates when signals change)
doubled = computed(() => count() * 2);

// effect() = runs side effects when signals change
effect(() => {
  console.log('count changed to:', count());
});
```

**Where signals are used in this app:**
- `ThemeService.isDark` → dark mode toggle
- `ProductService.products` → product list (CRUD)
- `CartService.items` → cart contents
- `AuthService.currentUser` → logged in user
- Component-level: `searchQuery`, `selectedCategory`, `sortBy`, `showForm`, etc.

---

## 🎨 Theming System

All colors are CSS variables. To change the theme, edit `src/styles.css`:

```css
[data-theme="light"] {
  --primary: #6366f1;   /* main color (indigo) */
  --bg: #f8fafc;        /* page background */
  --card-bg: #ffffff;   /* card background */
  --text: #0f172a;      /* main text */
}

[data-theme="dark"] {
  --primary: #818cf8;
  --bg: #0f172a;
  --card-bg: #1e293b;
  --text: #f1f5f9;
}
```

---

## 🗺️ All Routes

| Path          | Component       | Protected?    |
|---------------|-----------------|---------------|
| `/`           | HomeComponent   | No            |
| `/shop`       | ShopComponent   | No            |
| `/shop/:id`   | ProductDetail   | No            |
| `/cart`       | CartComponent   | No            |
| `/about`      | AboutComponent  | No            |
| `/contact`    | ContactComponent| No            |
| `/login`      | LoginComponent  | No            |
| `/register`   | RegisterComponent| No           |
| `/dashboard`  | DashboardComponent | Admin only |

---

## 🔧 Angular Version & Dependencies

| Package         | Version |
|-----------------|---------|
| Angular         | 19.x    |
| TypeScript      | 5.6.x   |
| Zone.js         | 0.15.x  |

**No external UI library needed.** Everything is built with custom CSS using CSS variables.
