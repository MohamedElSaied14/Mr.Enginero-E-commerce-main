export interface IProduct {
  id: number;
  name: string;
  price: number;
  quantity: number;
  imgUrl: string;
  categoryId: number;
  description: string;
  isNew: boolean;
  isBought: boolean;   // true = currently in cart (enables Cancel button)
}
