import { Routes } from '@angular/router';
import { adminGuard } from './guards/auth.guard';

export const routes: Routes = [
  { path: '', loadComponent: () => import('./Components/home/home').then(m => m.HomeComponent) },
  { path: 'shop', loadComponent: () => import('./Components/shop/shop').then(m => m.ShopComponent) },
  { path: 'about', loadComponent: () => import('./Components/about/about').then(m => m.AboutComponent) },
  { path: 'contact', loadComponent: () => import('./Components/contact/contact').then(m => m.ContactComponent) },
  { path: 'login', loadComponent: () => import('./Components/login/login').then(m => m.LoginComponent) },
  { path: 'register', loadComponent: () => import('./Components/register/register').then(m => m.RegisterComponent) },
  { path: 'dashboard', loadComponent: () => import('./Components/dashboard/dashboard').then(m => m.DashboardComponent), canActivate: [adminGuard] },
  { path: 'product/:id', loadComponent: () => import('./Components/product-details/product-details').then(m => m.ProductDetailsComponent) },
  { path: '**', redirectTo: '' }
];
