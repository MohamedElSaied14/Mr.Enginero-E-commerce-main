import { Injectable, signal, computed } from '@angular/core';

export interface IUser {
  id: number;
  name: string;
  email: string;
  password: string;
  role: 'admin' | 'user';
}

@Injectable({ providedIn: 'root' })
export class AuthService {

  private _users = signal<IUser[]>([
    { id: 1, name: 'Admin',   email: 'admin@store.com', password: 'admin123', role: 'admin' },
    { id: 2, name: 'Ahmed',   email: 'ahmed@store.com', password: 'user123',  role: 'user'  },
  ]);

  private _currentUser = signal<IUser | null>(null);

  // Public computed signals
  currentUser  = computed(() => this._currentUser());
  isLoggedIn   = computed(() => this._currentUser() !== null);
  isAdmin      = computed(() => this._currentUser()?.role === 'admin');
  userName     = computed(() => this._currentUser()?.name ?? '');

  login(email: string, password: string): boolean {
    const user = this._users().find(u => u.email === email && u.password === password);
    if (user) { this._currentUser.set(user); return true; }
    return false;
  }

  register(name: string, email: string, password: string, role: 'admin' | 'user' = 'user'): boolean {
    if (this._users().find(u => u.email === email)) return false; // already exists
    const maxId = Math.max(0, ...this._users().map(u => u.id));
    this._users.update(list => [...list, { id: maxId + 1, name, email, password, role }]);
    return true;
  }

  logout(): void {
    this._currentUser.set(null);
  }
}
