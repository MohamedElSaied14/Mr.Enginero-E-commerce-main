import { Injectable } from '@angular/core';
import { IProduct } from '../Models/iproduct';

@Injectable({
  providedIn: 'root',
})
export class StaticData {

  prdList: IProduct[];

  constructor() {
    this.prdList = [
      { id: 1,  name: 'Win10',     price: 4500,  quantity: 3, imgUrl: 'https://images2.alphacoders.com/550/thumb-440-550405.webp',                                          categoryId: 1, description: 'Windows 10 operating system with lifetime activation, regular security updates, and full compatibility with modern applications and drivers.', isNew: true,  isBought: false },
      { id: 2,  name: 'Win11',     price: 3200,  quantity: 1, imgUrl: 'https://images4.alphacoders.com/115/thumb-440-1152306.webp',                                          categoryId: 1, description: 'Windows 11 OS featuring a modern interface, improved performance, advanced security, and optimized support for gaming and productivity tools.',    isNew: false, isBought: false },
      { id: 3,  name: 'Rams',      price: 3000,  quantity: 5, imgUrl: 'https://c0.wallpaperflare.com/preview/115/85/121/chip-green-gold-circuit.jpg',                        categoryId: 2, description: '8GB DDR4 high-speed RAM module designed for gaming, multitasking, and heavy software usage with stable and efficient performance.',                 isNew: true,  isBought: false },
      { id: 4,  name: 'Dell XPS',  price: 40000, quantity: 5, imgUrl: 'https://c4.wallpaperflare.com/wallpaper/121/692/10/dell-spiderman-computer-laptop-wallpaper-preview.jpg', categoryId: 2, description: 'Premium Dell XPS laptop with powerful processor, stunning display, long battery life, and ultra-slim professional design.',                       isNew: true,  isBought: false },
      { id: 5,  name: 'Dell 5500', price: 23000, quantity: 8, imgUrl: 'https://c4.wallpaperflare.com/wallpaper/943/89/96/4k-astronaut-dell-laptop-dragon-wallpaper-preview.jpg', categoryId: 2, description: 'Dell 5500 FHD 15.6-inch laptop with strong performance, durable build quality, and reliable battery for daily work and study.',                    isNew: false, isBought: false },
      { id: 6,  name: 'Mac',       price: 1200,  quantity: 0, imgUrl: 'https://c4.wallpaperflare.com/wallpaper/461/319/628/computer-computers-2560x1440-mac-os-x-lion-wallpaper-preview.jpg', categoryId: 2, description: 'Apple MacBook featuring macOS system, sleek aluminum body, smooth performance, and excellent battery optimization.',                      isNew: false, isBought: false },
    { id: 7,  name: 'Nvidea',    price: 2100,  quantity: 4, imgUrl: 'https://c4.wallpaperflare.com/wallpaper/885/625/125/computer-gigabyte-msi-gpus-wallpaper-preview.jpg', categoryId: 3, description: 'NVIDIA graphics card built for high-performance gaming, video rendering, and AI applications with advanced cooling technology.',                    isNew: true,  isBought: false },
    { id: 8,  name: 'Rtx',       price: 1800,  quantity: 2, imgUrl: 'https://c4.wallpaperflare.com/wallpaper/984/768/1003/rtx-nvidia-gpu-4090-hd-wallpaper-preview.jpg',   categoryId: 3, description: 'RTX graphics card delivering real-time ray tracing, ultra-high FPS gaming experience, and powerful GPU acceleration.',                             isNew: false, isBought: false },
    { id: 9,  name: 'Igame',     price: 1350,  quantity: 1, imgUrl: 'https://c4.wallpaperflare.com/wallpaper/3/582/363/nvidia-geforce-graphics-card-gpus-wallpaper-preview.jpg', categoryId: 3, description: 'Colorful iGame graphics card designed for gamers seeking reliable performance, stylish RGB lighting, and stable frame rates.',                  isNew: false, isBought: false },
    { id: 10, name: 'Intel',     price: 6500,  quantity: 3, imgUrl: 'https://c4.wallpaperflare.com/wallpaper/634/394/413/cpu-computer-intel-wallpaper-preview.jpg',         categoryId: 4, description: 'Intel processor engineered for multitasking, gaming, and professional workloads with high clock speeds and energy efficiency.',                   isNew: true,  isBought: false },
    { id: 11, name: 'AMD',       price: 4200,  quantity: 0, imgUrl: 'https://c4.wallpaperflare.com/wallpaper/731/220/1023/amd-cpu-ryzen-threadripper-wallpaper-preview.jpg',categoryId: 4, description: 'AMD Ryzen processor offering powerful multi-core performance, advanced architecture, and excellent value for high-demand tasks.',                    isNew: false, isBought: false },
    { id: 12, name: 'Intel I7',  price: 3900,  quantity: 2, imgUrl: 'https://c4.wallpaperflare.com/wallpaper/374/615/674/intel-firm-processor-cpu-wallpaper-preview.jpg',  categoryId: 4, description: 'Intel Core i7 processor optimized for high-speed computing, smooth multitasking, and professional content creation.',                             isNew: true,  isBought: false },
  ];
  }

  getAllProducts(): IProduct[] {
    return this.prdList;
  }

  getProductById(id: number): IProduct | undefined {
    return this.prdList.find(product => product.id === id);
  }

  getProductsByCategory(categoryId: number): IProduct[] {
    return this.prdList.filter(product => product.categoryId === categoryId);
  }

  getProductsByIds(ids: number[]): IProduct[] {
    return this.prdList.filter(product => ids.includes(product.id));
  }

  getProductsByName(name: string): IProduct[] {
    return this.prdList.filter(product => product.name.toLowerCase().includes(name.toLowerCase()));
  }

  getProductsByPriceRange(min: number, max: number): IProduct[] {
    return this.prdList.filter(product => product.price >= min && product.price <= max);
  }

  getProductsByAvailability(isAvailable: boolean): IProduct[] {
    return this.prdList.filter(product => product.quantity > 0 === isAvailable);
  }

}
