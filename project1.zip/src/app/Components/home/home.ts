import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [CommonModule],
  template: `
    <!-- Hero Carousel -->
    <div id="carouselHome" class="carousel slide" data-bs-ride="carousel">
      <div class="carousel-indicators">
        <button type="button" data-bs-target="#carouselHome" data-bs-slide-to="0" class="active"></button>
        <button type="button" data-bs-target="#carouselHome" data-bs-slide-to="1"></button>
        <button type="button" data-bs-target="#carouselHome" data-bs-slide-to="2"></button>
      </div>
      <div class="carousel-inner" style="max-height:520px;overflow:hidden;">
        <div class="carousel-item active">
          <img src="https://4kwallpapers.com/images/walls/thumbs_3t/24760.jpg" class="d-block w-100" style="object-fit:cover;height:520px;" alt="Slide 1">
          <div class="carousel-caption d-none d-md-block">
            <h1 class="display-4 fw-bold"></h1>
            <p class="lead">Top-tier tech at your fingertips</p>
            <button class="btn btn-light btn-lg mt-2" (click)="goToShop()">Shop Now →</button>
          </div>
        </div>
        <div class="carousel-item">
          <img src="https://4kwallpapers.com/images/walls/thumbs_3t/22868.jpg" class="d-block w-100" style="object-fit:cover;height:520px;" alt="Slide 2">
          <div class="carousel-caption d-none d-md-block">
            <h1 class="display-4 fw-bold">New Arrivals</h1>
            <p class="lead">Discover the latest GPUs, CPUs & Laptops</p>
            <button class="btn btn-light btn-lg mt-2" (click)="goToShop()">Browse →</button>
          </div>
        </div>
        <div class="carousel-item">
          <img src="https://4kwallpapers.com/images/walls/thumbs_3t/5781.jpg" class="d-block w-100" style="object-fit:cover;height:520px;" alt="Slide 3">
          <div class="carousel-caption d-none d-md-block">
            <h1 class="display-4 fw-bold">Build Your Rig</h1>
            <p class="lead">Everything you need in one place</p>
            <button class="btn btn-light btn-lg mt-2" (click)="goToShop()">Start Building →</button>
          </div>
        </div>
      </div>
      <button class="carousel-control-prev" type="button" data-bs-target="#carouselHome" data-bs-slide="prev">
        <span class="carousel-control-prev-icon"></span>
      </button>
      <button class="carousel-control-next" type="button" data-bs-target="#carouselHome" data-bs-slide="next">
        <span class="carousel-control-next-icon"></span>
      </button>
    </div>

    <!-- Features Section -->
    <section class="py-5 text-center">
      <div class="container">
        <h2 class="mb-4">Why Choose Us?</h2>
        <div class="row g-4">
          <div class="col-md-4" *ngFor="let f of features">
            <div class="card h-100 shadow-sm border-0 p-4">
              <div class="display-4 mb-3">{{f.icon}}</div>
              <h5 class="fw-bold">{{f.title}}</h5>
              <p class="text-muted">{{f.text}}</p>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- CTA -->
    <section class="py-5" style="background:linear-gradient(135deg,#1a0810,#3d0f20);color:white;text-align:center;">
      <h2 class="display-6 fw-bold mb-3">Ready to upgrade your setup?</h2>
      <p class="lead mb-4">Browse hundreds of tech products at unbeatable prices</p>
      <button class="btn btn-light btn-lg px-5" (click)="goToShop()">Explore the Shop</button>
    </section>
  `
})
export class HomeComponent {
  constructor(private router: Router) {}

  features = [
    { icon: '🚀', title: 'Fast Delivery',    text: 'Get your order within 24-48 hours anywhere in Egypt.' },
    { icon: '🛡️', title: 'Warranty',         text: '1-year warranty on all hardware products.' },
    { icon: '💬', title: '24/7 Support',     text: 'Our team is always here to help you choose the best.' },
  ];

  goToShop() { this.router.navigate(['/shop']); }
}
