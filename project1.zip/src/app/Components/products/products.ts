import { Component, EventEmitter, Input, OnChanges, OnInit, Output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { IProduct } from '../../Models/iproduct';
import { CalcPipe } from '../../pipes/calc-pipe-pipe';
import { ProductService } from '../../services/product.service';

@Component({
  selector: 'app-products',
  standalone: true,
  imports: [CommonModule, CalcPipe, RouterLink],
  templateUrl: './products.html',
  styleUrls: ['./products.css'],
})
export class ProductsComponent implements OnInit, OnChanges {
  @Input()  recievedID: number = 0;
  @Output() total      = new EventEmitter<number>();
  @Output() cancelItem = new EventEmitter<number>();

  constructor(private productSvc: ProductService) {}

  totalPrice:     number = 0;
  filteratedList: IProduct[] = [];
  selectedQty:    Record<number,number> = {};
  boughtQty:      Record<number,number> = {};
  expanded:       Record<number,boolean> = {};

  ngOnInit():    void { this.filteratedList = this.productSvc.getByCategory(this.recievedID); }
  ngOnChanges(): void { this.filteratedList = this.productSvc.getByCategory(this.recievedID); }

  getQty(p: IProduct): number { return this.selectedQty[p.id] ?? 1; }

  decreaseQty(p: IProduct): void {
    const c = this.getQty(p); if (c > 1) this.selectedQty[p.id] = c - 1;
  }
  increaseQty(p: IProduct): void {
    const c = this.getQty(p); if (c < p.quantity) this.selectedQty[p.id] = c + 1;
  }

  addToCart(p: IProduct): void {
    const qty = this.getQty(p);
    if (p.quantity === 0 || p.isBought || qty < 1) return;
    p.isBought = true;
    p.quantity -= qty;
    this.boughtQty[p.id] = qty;
    this.totalPrice += p.price * qty;
    this.total.emit(this.totalPrice);
    this.productSvc.updateProduct(p);
  }

  cancelFromCart(p: IProduct): void {
    if (!p.isBought) return;
    const qty    = this.boughtQty[p.id] ?? 1;
    const refund = p.price * qty;
    p.isBought = false;
    p.quantity += qty;
    this.boughtQty[p.id]   = 0;
    this.selectedQty[p.id] = 1;
    this.totalPrice = Math.max(0, this.totalPrice - refund);
    this.cancelItem.emit(refund);
    this.productSvc.updateProduct(p);
  }

  toggleDescription(id: number): void { this.expanded[id] = !this.expanded[id]; }
}
