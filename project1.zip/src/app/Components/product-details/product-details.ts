import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { IProduct } from '../../Models/iproduct';
import { ProductService } from '../../services/product.service';
import { CalcPipe } from '../../pipes/calc-pipe-pipe';

@Component({
  selector: 'app-product-details',
  standalone: true,
  imports: [CommonModule, CalcPipe, FormsModule],
  templateUrl: './product-details.html',
  styleUrls: ['./product-details.css'],
})
export class ProductDetailsComponent implements OnInit {
  product: IProduct | undefined;
  userRating: number = 0;
  hoveredStar: number = 0;
  submitted: boolean = false;
  reviewText: string = '';
  reviews: { name: string; rating: number; comment: string; date: string }[] = [
    { name: 'Ahmed M.', rating: 5, comment: 'Excellent product! Highly recommended. Works perfectly out of the box.', date: '2024-12-10' },
    { name: 'Sara K.', rating: 4, comment: 'Great quality and fast delivery. Very satisfied with this purchase.', date: '2024-11-22' },
    { name: 'Omar T.', rating: 3, comment: 'Good product overall, but packaging could be better.', date: '2024-10-15' },
  ];

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private productSvc: ProductService
  ) {}

  ngOnInit(): void {
    const id = Number(this.route.snapshot.paramMap.get('id'));
    this.product = this.productSvc.getById(id);
    if (!this.product) this.router.navigate(['/']);
  }

  get averageRating(): number {
    if (this.reviews.length === 0) return 0;
    return this.reviews.reduce((sum, r) => sum + r.rating, 0) / this.reviews.length;
  }

  get ratingDistribution(): { star: number; count: number; pct: number }[] {
    return [5, 4, 3, 2, 1].map(star => {
      const count = this.reviews.filter(r => r.rating === star).length;
      return { star, count, pct: this.reviews.length ? (count / this.reviews.length) * 100 : 0 };
    });
  }

  setHover(star: number): void { this.hoveredStar = star; }
  clearHover(): void { this.hoveredStar = 0; }
  setRating(star: number): void { this.userRating = star; }

  submitReview(): void {
    if (this.userRating === 0) return;
    this.reviews.unshift({
      name: 'You',
      rating: this.userRating,
      comment: this.reviewText || 'No comment provided.',
      date: new Date().toISOString().split('T')[0],
    });
    this.submitted = true;
    this.userRating = 0;
    this.reviewText = '';
    setTimeout(() => (this.submitted = false), 3000);
  }

  goBack(): void { this.router.navigate(['/shop']); }

  addToCart(): void {
    if (!this.product || this.product.isBought || this.product.quantity === 0) return;
    this.product.isBought = true;
    this.product.quantity -= 1;
    this.productSvc.updateProduct(this.product);
  }

  starsArray(n: number): number[] {
    return Array.from({ length: 5 }, (_, i) => i + 1);
  }
}
