import { Component, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { Router, RouterModule } from '@angular/router';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-register',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule],
  template: `
    <div class="d-flex justify-content-center align-items-center" style="min-height:80vh;padding:2rem;">
      <div class="card shadow border-0 p-4" style="width:100%;max-width:420px;">
        <h2 class="text-center fw-bold mb-1">Create Account</h2>
        <p class="text-center text-muted mb-4">Join Mr_Enginero today</p>

        @if (error()) {
          <div class="alert alert-danger py-2">{{error()}}</div>
        }
        @if (success()) {
          <div class="alert alert-success py-2">Account created! <a routerLink="/login">Login now</a></div>
        }

        <div class="mb-3">
          <label class="form-label fw-semibold">Full Name</label>
          <input type="text" class="form-control" [(ngModel)]="name" placeholder="Your name" />
        </div>
        <div class="mb-3">
          <label class="form-label fw-semibold">Email</label>
          <input type="email" class="form-control" [(ngModel)]="email" placeholder="your@email.com" />
        </div>
        <div class="mb-3">
          <label class="form-label fw-semibold">Password</label>
          <input type="password" class="form-control" [(ngModel)]="password" placeholder="Min 6 characters" />
        </div>
        <div class="mb-4">
          <label class="form-label fw-semibold">Role</label>
          <select class="form-select" [(ngModel)]="role">
            <option value="user">👤 User</option>
            <option value="admin">👑 Admin</option>
          </select>
        </div>
        <button class="btn btn-dark w-100 mb-3" (click)="register()">Create Account</button>
        <p class="text-center text-muted small">Already have an account? <a routerLink="/login">Sign in</a></p>
      </div>
    </div>
  `
})
export class RegisterComponent {
  name     = '';
  email    = '';
  password = '';
  role: 'admin' | 'user' = 'user';
  error   = signal('');
  success = signal(false);

  constructor(private auth: AuthService, private router: Router) {}

  register(): void {
    this.error.set('');
    if (!this.name || !this.email || !this.password) { this.error.set('All fields are required'); return; }
    if (this.password.length < 6) { this.error.set('Password must be at least 6 characters'); return; }
    const ok = this.auth.register(this.name, this.email, this.password, this.role);
    if (ok) { this.success.set(true); }
    else     { this.error.set('Email already in use'); }
  }
}
