import { Component, HostListener, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { AuthService } from '../../services/auth.service';
import { ThemeService } from '../../services/theme.service';
import { ProductService } from '../../services/product.service';
import { IProduct } from '../../Models/iproduct';

@Component({
  selector: 'app-header',
  standalone: true,
  imports: [CommonModule, RouterModule, FormsModule],
  templateUrl: './header.html',
  styleUrls: ['./header.css']
})
export class Header {
  isScrolled  = false;
  menuOpen    = false;
  searchOpen  = signal(false);
  searchQuery = '';
  searchResults = signal<IProduct[]>([]);

  constructor(
    public auth: AuthService,
    public theme: ThemeService,
    private productSvc: ProductService,
    private router: Router
  ) {}

  @HostListener('window:scroll')
  onScroll(): void { this.isScrolled = window.scrollY > 30; }

  toggleMenu()  { this.menuOpen = !this.menuOpen; }
  closeMenu()   { this.menuOpen = false; }

  toggleSearch(): void {
    this.searchOpen.update(v => !v);
    if (!this.searchOpen()) { this.searchQuery = ''; this.searchResults.set([]); }
  }

  onSearch(): void {
    if (this.searchQuery.trim().length > 0) {
      this.searchResults.set(this.productSvc.searchByName(this.searchQuery));
    } else {
      this.searchResults.set([]);
    }
  }

  goToProduct(p: IProduct): void {
    this.router.navigate(['/shop']);
    this.searchOpen.set(false);
    this.searchQuery = '';
    this.searchResults.set([]);
  }

  goToShopSection(): void {
    this.router.navigate(['/shop']).then(() => {
      setTimeout(() => {
        document.getElementById('products-section')?.scrollIntoView({ behavior: 'smooth' });
      }, 100);
    });
    this.closeMenu();
  }

  logout(): void {
    this.auth.logout();
    this.router.navigate(['/']);
  }
}
