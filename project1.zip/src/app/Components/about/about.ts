import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-about',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="container py-5">
      <div class="text-center mb-5">
        <h1 class="display-5 fw-bold">About Mr_Enginero</h1>
        <p class="lead text-muted">Your trusted tech store since 2020</p>
      </div>
      <div class="row g-4 align-items-center">
        <div class="col-md-6">
          <img src="https://c4.wallpaperflare.com/wallpaper/634/394/413/cpu-computer-intel-wallpaper-preview.jpg" class="img-fluid rounded shadow" alt="About Us" />
        </div>
        <div class="col-md-6">
          <h3 class="fw-bold mb-3">Our Story</h3>
          <p>We started Mr_Enginero with a simple mission: to make top-tier computer hardware accessible to everyone in Egypt. From powerful CPUs to high-end GPUs and everything in between, we carry only the best.</p>
          <p>Our team of engineers carefully tests every product before listing it, so you can buy with confidence.</p>
          <div class="row g-3 mt-3">
            <div class="col-6" *ngFor="let stat of stats">
              <div class="card border-0 shadow-sm text-center p-3">
                <h3 class="fw-bold" style="color:#a0394a;">{{stat.value}}</h3>
                <p class="mb-0 text-muted small">{{stat.label}}</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  `
})
export class AboutComponent {
  stats = [
    { value: '5+',   label: 'Years in Business' },
    { value: '1200+', label: 'Happy Customers' },
    { value: '200+', label: 'Products' },
    { value: '24/7', label: 'Support' },
  ];
}
