import { Component, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { Router, RouterModule } from '@angular/router';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule],
  template: `
    <div class="d-flex justify-content-center align-items-center" style="min-height:80vh;padding:2rem;">
      <div class="card shadow border-0 p-4" style="width:100%;max-width:420px;">
        <h2 class="text-center fw-bold mb-1">Welcome Back</h2>
        <p class="text-center text-muted mb-4">Sign in to your account</p>

        @if (error()) {
          <div class="alert alert-danger py-2">{{error()}}</div>
        }

        <div class="mb-3">
          <label class="form-label fw-semibold">Email</label>
          <input type="email" class="form-control" [(ngModel)]="email" placeholder="your@email.com" />
        </div>
        <div class="mb-3">
          <label class="form-label fw-semibold">Password</label>
          <input type="password" class="form-control" [(ngModel)]="password" (keydown.enter)="login()" placeholder="Password" />
        </div>
        <button class="btn btn-dark w-100 mb-3" (click)="login()">Sign In</button>

        <p class="text-center text-muted small">
          Don't have an account?
          <a routerLink="/register">Register here</a>
        </p>

        <hr class="my-3">
        <p class="text-muted small text-center mb-1">Demo accounts:</p>
        <div class="row g-2">
          <div class="col-6">
            <button class="btn btn-outline-secondary w-100 btn-sm" (click)="fillAdmin()">👑 Admin</button>
          </div>
          <div class="col-6">
            <button class="btn btn-outline-secondary w-100 btn-sm" (click)="fillUser()">👤 User</button>
          </div>
        </div>
      </div>
    </div>
  `
})
export class LoginComponent {
  email    = '';
  password = '';
  error    = signal('');

  constructor(private auth: AuthService, private router: Router) {}

  login(): void {
    if (!this.email || !this.password) { this.error.set('Please fill in all fields'); return; }
    const ok = this.auth.login(this.email, this.password);
    if (ok) {
      this.router.navigate([this.auth.isAdmin() ? '/dashboard' : '/shop']);
    } else {
      this.error.set('Invalid email or password');
    }
  }

  fillAdmin() { this.email = 'admin@store.com'; this.password = 'admin123'; }
  fillUser()  { this.email = 'ahmed@store.com'; this.password = 'user123';  }
}
