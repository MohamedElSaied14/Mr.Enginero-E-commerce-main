import { Component, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-contact',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="container py-5" style="max-width:700px;">
      <div class="text-center mb-5">
        <h1 class="display-5 fw-bold">Contact Us</h1>
        <p class="lead text-muted">We'd love to hear from you</p>
      </div>

      @if (submitted()) {
        <div class="alert alert-success text-center">
          <h5>✅ Message Sent!</h5>
          <p class="mb-0">Thank you, <strong>{{form.name}}</strong>! We'll get back to you at <strong>{{form.email}}</strong> soon.</p>
        </div>
      } @else {
        <div class="card shadow border-0 p-4">
          <div class="mb-3">
            <label class="form-label fw-semibold">Name</label>
            <input type="text" class="form-control" [(ngModel)]="form.name" placeholder="Your name" />
          </div>
          <div class="mb-3">
            <label class="form-label fw-semibold">Email</label>
            <input type="email" class="form-control" [(ngModel)]="form.email" placeholder="your@email.com" />
          </div>
          <div class="mb-3">
            <label class="form-label fw-semibold">Message</label>
            <textarea class="form-control" rows="5" [(ngModel)]="form.message" placeholder="How can we help?"></textarea>
          </div>
          <button class="btn btn-dark w-100" (click)="submit()" [disabled]="!form.name || !form.email || !form.message">
            Send Message
          </button>
        </div>
      }

      <div class="row g-3 mt-4 text-center">
        <div class="col-4"><div class="card border-0 shadow-sm p-3">📧<br><small>admin&#64;store.com</small></div></div>
        <div class="col-4"><div class="card border-0 shadow-sm p-3">📞<br><small>+20 100 000 0000</small></div></div>
        <div class="col-4"><div class="card border-0 shadow-sm p-3">📍<br><small>Cairo, Egypt</small></div></div>
      </div>
    </div>
  `
})
export class ContactComponent {
  submitted = signal(false);
  form = { name: '', email: '', message: '' };
  submit() { if (this.form.name && this.form.email && this.form.message) this.submitted.set(true); }
}
