import { Component, OnInit, signal, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { ProductService } from '../../services/product.service';
import { IProduct } from '../../Models/iproduct';
import { CalcPipe } from '../../pipes/calc-pipe-pipe';

@Component({
  selector: 'app-shop',
  standalone: true,
  imports: [CommonModule, FormsModule, CalcPipe, RouterLink],
  template: `
    <div class="container-fluid px-4 py-4">

      <!-- Page Title -->
      <div class="text-center py-4" id="products-section">
        <p class="flaura-section-sub">Curated For You</p>
        <h2 class="flaura-section-title">The Collection</h2>
        <div class="flaura-divider mx-auto"></div>
      </div>

      <!-- Cart Summary Bar -->
      <div class="flaura-cart-bar d-flex align-items-center justify-content-between px-4 py-2 mb-3">
        <span class="flaura-cart-label">🛍 <strong>{{cartCount()}}</strong> {{cartCount() === 1 ? 'item' : 'items'}}</span>
        <span class="d-none d-sm-inline" style="color:yellow;">thanks for buying</span>
        <div class="flaura-total-pill" [class.has-total]="grandTotal() > 0">
          <span class="flaura-total-label">Items Total:</span>
          <span class="flaura-total-amount">EGP {{grandTotal().toLocaleString('en-EG',{minimumFractionDigits:2})}}</span>
        </div>
      </div>

      <!-- Filters Row -->
      <div class="row g-3 mb-4 align-items-end">

        <!-- Search by name -->
        <div class="col-12 col-md-4">
          <label class="form-label fw-semibold">🔍 Search by Name</label>
          <input type="text" class="form-control" placeholder="e.g. Dell, Intel..."
            [(ngModel)]="nameFilter" (ngModelChange)="applyFilters()" />
        </div>

        <!-- Category filter -->
        <div class="col-12 col-md-4">
          <label class="form-label fw-semibold">📂 Category</label>
          <div class="d-flex flex-wrap gap-2">
            @for (cat of catList; track cat.id) {
              <button class="btn flaura-cat-btn" [class.active]="selectedCatId() === cat.id"
                (click)="selectCategory(cat.id)">{{cat.name}}</button>
            }
          </div>
        </div>

        <!-- Price range -->
        <div class="col-12 col-md-4">
          <label class="form-label fw-semibold">💰 Price Range (EGP)</label>
          <div class="d-flex gap-2 align-items-center">
            <input type="number" class="form-control form-control-sm" placeholder="Min" [(ngModel)]="minPrice" (ngModelChange)="applyFilters()" />
            <span>–</span>
            <input type="number" class="form-control form-control-sm" placeholder="Max" [(ngModel)]="maxPrice" (ngModelChange)="applyFilters()" />
            <button class="btn btn-outline-secondary btn-sm" (click)="clearFilters()">Clear</button>
          </div>
        </div>

      </div>

      <!-- Results count -->
      <p class="text-muted small mb-3">Showing {{filteredProducts().length}} product(s)</p>

      <!-- Product Grid -->
      <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 row-cols-lg-4 g-4">
        @for (p of filteredProducts(); track p.id) {
          <div class="col">
            <div class="flaura-card h-100"
              [class.out-of-stock]="p.quantity === 0 && !p.isBought"
              [class.in-cart]="p.isBought">

              <!-- Image + Badges -->
              <div class="position-relative flaura-img-wrapper">
                <img [src]="p.imgUrl" [alt]="p.name" class="flaura-card-img" />
                @if (p.isNew && p.quantity > 0 && !p.isBought) {
                  <span class="badge flaura-badge-new position-absolute top-0 start-0 m-2">NEW</span>
                }
                @if (p.quantity === 0 && !p.isBought) {
                  <span class="badge flaura-badge-sold position-absolute top-0 start-0 m-2">SOLD OUT</span>
                }
                @if (p.quantity === 1 && !p.isBought) {
                  <span class="badge flaura-badge-last position-absolute top-0 end-0 m-2">LAST ONE</span>
                }
                @if (p.isBought) {
                  <span class="badge flaura-badge-cart position-absolute top-0 start-0 m-2">
                    ✓ IN CART ×{{boughtQty[p.id]}}
                  </span>
                }
              </div>

              <!-- Body -->
              <div class="p-3 d-flex flex-column gap-2">
                <p class="flaura-description mb-0">
                  {{expanded[p.id] ? p.description : (p.description.slice(0,60))}}
                  @if (!expanded[p.id] && p.description.length > 60) { ... }
                  @if (p.description.length > 60) {
                    <button class="btn btn-link p-0 ms-1" (click)="expanded[p.id] = !expanded[p.id]">
                      {{expanded[p.id] ? 'See Less' : 'See More'}}
                    </button>
                  }
                </p>
                <h6 class="flaura-product-name mb-0">{{p.name}}</h6>
                <p class="flaura-price mb-0">{{p.price | calc}}</p>

                @if (!p.isBought && p.quantity > 0) {
                  <div class="flaura-qty-row">
                    <button class="flaura-qty-btn" (click)="decreaseQty(p)" [disabled]="getQty(p) <= 1">−</button>
                    <span class="flaura-qty-value">{{getQty(p)}}</span>
                    <button class="flaura-qty-btn" (click)="increaseQty(p)" [disabled]="getQty(p) >= p.quantity">+</button>
                    <span class="flaura-qty-stock">/ {{p.quantity}} left</span>
                  </div>
                  @if (getQty(p) > 1) {
                    <p class="flaura-subtotal mb-0">Subtotal: {{p.price * getQty(p) | calc}}</p>
                  }
                }

                @if (!p.isBought) {
                  <button class="btn flaura-btn-add mt-1" (click)="addToCart(p)" [disabled]="p.quantity === 0">
                    🛒 {{p.quantity === 0 ? 'Out of Stock' : 'Add to Cart'}}
                  </button>
                }
                @if (p.isBought) {
                  <div class="flaura-bought-summary">
                    <span>{{boughtQty[p.id]}} × {{p.price | calc}}</span>
                    <span class="flaura-bought-total">= {{p.price * boughtQty[p.id] | calc}}</span>
                  </div>
                  <button class="btn flaura-btn-cancel mt-1" (click)="cancelFromCart(p)">↩ Cancel & Return</button>
                }

                <!-- VIEW DETAILS -->
                <a class="btn flaura-btn-details mt-1" [routerLink]="['/product', p.id]">
                  🔍 View Details & Reviews
                </a>
              </div>
            </div>
          </div>
        }
      </div>

      @if (filteredProducts().length === 0) {
        <div class="text-center py-5">
          <p class="text-muted fs-5">No products match your filters. <button class="btn btn-link p-0" (click)="clearFilters()">Clear filters</button></p>
        </div>
      }
    </div>
  `
})
export class ShopComponent implements OnInit {
  constructor(private productSvc: ProductService) {}

  // Signals
  selectedCatId = signal<number>(0);
  grandTotal    = signal<number>(0);
  cartCount     = signal<number>(0);
  filteredProducts = signal<IProduct[]>([]);

  // Local filter state
  nameFilter = '';
  minPrice: number | null = null;
  maxPrice: number | null = null;

  // Cart tracking
  selectedQty: Record<number,number> = {};
  boughtQty:   Record<number,number> = {};
  expanded:    Record<number,boolean> = {};

  catList = [
    { id: 0, name: 'All Pieces' },
    { id: 1, name: 'Elec' },
    { id: 2, name: 'Laptops' },
    { id: 3, name: 'Gpu' },
    { id: 4, name: 'Cpu' },
  ];

  ngOnInit(): void { this.applyFilters(); }

  selectCategory(id: number): void {
    this.selectedCatId.set(id);
    this.applyFilters();
  }

  applyFilters(): void {
    let list = this.productSvc.getAll();

    // Category
    if (this.selectedCatId() !== 0) {
      list = list.filter(p => p.categoryId === this.selectedCatId());
    }
    // Name
    if (this.nameFilter.trim()) {
      list = list.filter(p => p.name.toLowerCase().includes(this.nameFilter.toLowerCase()));
    }
    // Price
    if (this.minPrice !== null) list = list.filter(p => p.price >= this.minPrice!);
    if (this.maxPrice !== null) list = list.filter(p => p.price <= this.maxPrice!);

    this.filteredProducts.set(list);
  }

  clearFilters(): void {
    this.nameFilter = '';
    this.minPrice = null;
    this.maxPrice = null;
    this.selectedCatId.set(0);
    this.applyFilters();
  }

  getQty(p: IProduct): number { return this.selectedQty[p.id] ?? 1; }

  decreaseQty(p: IProduct): void {
    const c = this.getQty(p); if (c > 1) this.selectedQty[p.id] = c - 1;
  }
  increaseQty(p: IProduct): void {
    const c = this.getQty(p); if (c < p.quantity) this.selectedQty[p.id] = c + 1;
  }

  addToCart(p: IProduct): void {
    const qty = this.getQty(p);
    if (p.quantity === 0 || p.isBought) return;
    p.isBought = true;
    p.quantity -= qty;
    this.boughtQty[p.id] = qty;
    this.grandTotal.update(t => t + p.price * qty);
    this.cartCount.update(c => c + 1);
    this.productSvc.updateProduct(p);
  }

  cancelFromCart(p: IProduct): void {
    if (!p.isBought) return;
    const qty    = this.boughtQty[p.id] ?? 1;
    const refund = p.price * qty;
    p.isBought = false;
    p.quantity += qty;
    this.boughtQty[p.id]   = 0;
    this.selectedQty[p.id] = 1;
    this.grandTotal.update(t => Math.max(0, t - refund));
    this.cartCount.update(c => Math.max(0, c - 1));
    this.productSvc.updateProduct(p);
  }
}
