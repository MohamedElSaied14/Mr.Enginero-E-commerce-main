import { Component, signal, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ProductService } from '../../services/product.service';
import { AuthService } from '../../services/auth.service';
import { IProduct } from '../../Models/iproduct';
import { Router } from '@angular/router';
import { CalcPipe } from '../../pipes/calc-pipe-pipe';

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [CommonModule, FormsModule, CalcPipe],
  template: `
    <div class="container-fluid py-4 px-4">

      <!-- Header -->
      <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
          <h2 class="fw-bold mb-0">👑 Admin Dashboard</h2>
          <p class="text-muted mb-0">Welcome, {{auth.userName()}}</p>
        </div>
        <button class="btn btn-outline-danger" (click)="logout()">Logout</button>
      </div>

      <!-- Stats -->
      <div class="row g-3 mb-4">
        <div class="col-6 col-md-3" *ngFor="let s of stats()">
          <div class="card border-0 shadow-sm text-center p-3">
            <h3 class="fw-bold" style="color:#a0394a;">{{s.value}}</h3>
            <p class="mb-0 text-muted small">{{s.label}}</p>
          </div>
        </div>
      </div>

      <!-- Add Product Form -->
      <div class="card shadow-sm border-0 mb-4">
        <div class="card-header bg-dark text-white fw-bold">
          {{editMode() ? '✏️ Edit Product' : '➕ Add New Product'}}
        </div>
        <div class="card-body">
          <div class="row g-3">
            <div class="col-md-4">
              <label class="form-label">Name</label>
              <input type="text" class="form-control" [(ngModel)]="form.name" placeholder="Product name" />
            </div>
            <div class="col-md-4">
              <label class="form-label">Price (EGP)</label>
              <input type="number" class="form-control" [(ngModel)]="form.price" placeholder="Price" />
            </div>
            <div class="col-md-4">
              <label class="form-label">Quantity</label>
              <input type="number" class="form-control" [(ngModel)]="form.quantity" placeholder="Stock" />
            </div>
            <div class="col-md-4">
              <label class="form-label">Category</label>
              <select class="form-select" [(ngModel)]="form.categoryId">
                <option value="1">Elec (OS)</option>
                <option value="2">Laptops</option>
                <option value="3">GPU</option>
                <option value="4">CPU</option>
              </select>
            </div>
            <div class="col-md-8">
              <label class="form-label">Image URL</label>
              <input type="text" class="form-control" [(ngModel)]="form.imgUrl" placeholder="https://..." />
            </div>
            <div class="col-12">
              <label class="form-label">Description</label>
              <textarea class="form-control" rows="2" [(ngModel)]="form.description" placeholder="Product description"></textarea>
            </div>
            <div class="col-6">
              <div class="form-check form-switch">
                <input class="form-check-input" type="checkbox" [(ngModel)]="form.isNew" id="isNewCheck">
                <label class="form-check-label" for="isNewCheck">Mark as NEW</label>
              </div>
            </div>
          </div>
          <div class="mt-3 d-flex gap-2">
            <button class="btn btn-dark" (click)="saveProduct()" [disabled]="!form.name || !form.price">
              {{editMode() ? 'Update Product' : 'Add Product'}}
            </button>
            @if (editMode()) {
              <button class="btn btn-secondary" (click)="cancelEdit()">Cancel</button>
            }
          </div>
        </div>
      </div>

      <!-- Products Table -->
      <div class="card shadow-sm border-0">
        <div class="card-header bg-dark text-white d-flex justify-content-between align-items-center">
          <span>📦 All Products ({{productSvc.getAll().length}})</span>
          <input type="text" class="form-control form-control-sm w-auto" [(ngModel)]="search"
            placeholder="Search..." style="max-width:200px;" />
        </div>
        <div class="card-body p-0">
          <div class="table-responsive">
            <table class="table table-hover mb-0 align-middle">
              <thead class="table-light">
                <tr>
                  <th>#</th>
                  <th>Image</th>
                  <th>Name</th>
                  <th>Price</th>
                  <th>Stock</th>
                  <th>Category</th>
                  <th>New?</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                @for (p of searchedProducts(); track p.id) {
                  <tr>
                    <td class="text-muted small">{{p.id}}</td>
                    <td><img [src]="p.imgUrl" width="50" height="40" style="object-fit:cover;border-radius:6px;" [alt]="p.name" /></td>
                    <td class="fw-semibold">{{p.name}}</td>
                    <td>{{p.price | calc}}</td>
                    <td>
                      <span class="badge" [class]="p.quantity > 0 ? 'bg-success' : 'bg-danger'">
                        {{p.quantity > 0 ? p.quantity + ' left' : 'Out of Stock'}}
                      </span>
                    </td>
                    <td><span class="badge bg-secondary">{{getCatName(p.categoryId)}}</span></td>
                    <td>{{p.isNew ? '✅' : '—'}}</td>
                    <td>
                      <div class="d-flex gap-1">
                        <button class="btn btn-sm btn-outline-primary" (click)="startEdit(p)">✏️ Edit</button>
                        <button class="btn btn-sm btn-outline-danger" (click)="deleteProduct(p.id)">🗑️ Delete</button>
                      </div>
                    </td>
                  </tr>
                }
              </tbody>
            </table>
          </div>
        </div>
      </div>

    </div>
  `
})
export class DashboardComponent {
  search   = '';
  editMode = signal(false);
  editId   = signal<number | null>(null);

  form: Partial<IProduct> & { isNew: boolean } = this.emptyForm();

  catNames: Record<number,string> = { 1:'Elec', 2:'Laptops', 3:'GPU', 4:'CPU' };

  constructor(
    public productSvc: ProductService,
    public auth: AuthService,
    private router: Router
  ) {}

  stats = computed(() => {
    const products = this.productSvc.getAll();
    return [
      { value: products.length, label: 'Total Products' },
      { value: products.filter(p => p.quantity > 0).length, label: 'In Stock' },
      { value: products.filter(p => p.quantity === 0).length, label: 'Out of Stock' },
      { value: products.filter(p => p.isNew).length, label: 'New Items' },
    ];
  });

  searchedProducts = computed(() => {
    const s = this.search.toLowerCase();
    return s ? this.productSvc.getAll().filter(p => p.name.toLowerCase().includes(s)) : this.productSvc.getAll();
  });

  getCatName(id: number): string { return this.catNames[id] ?? 'Unknown'; }

  emptyForm(): any {
    return { name:'', price:0, quantity:0, categoryId:1, imgUrl:'', description:'', isNew:false, isBought:false };
  }

  saveProduct(): void {
    if (!this.form.name || !this.form.price) return;
    if (this.editMode()) {
      this.productSvc.updateProduct({ ...this.form, id: this.editId()! } as IProduct);
      this.editMode.set(false);
      this.editId.set(null);
    } else {
      this.productSvc.addProduct(this.form as Omit<IProduct,'id'>);
    }
    this.form = this.emptyForm();
  }

  startEdit(p: IProduct): void {
    this.form = { ...p };
    this.editMode.set(true);
    this.editId.set(p.id);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  cancelEdit(): void {
    this.editMode.set(false);
    this.editId.set(null);
    this.form = this.emptyForm();
  }

  deleteProduct(id: number): void {
    if (confirm('Are you sure you want to delete this product?')) {
      this.productSvc.deleteProduct(id);
    }
  }

  logout(): void {
    this.auth.logout();
    this.router.navigate(['/']);
  }
}
