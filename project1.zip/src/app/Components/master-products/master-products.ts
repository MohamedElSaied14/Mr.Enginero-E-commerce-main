import { Component } from '@angular/core';
import { ProductsComponent } from '../products/products';
import { NgClass } from '@angular/common';
import { ICategory } from '../../Models/icategory';

@Component({
  selector: 'app-master-products',
  standalone: true,
  imports: [NgClass, ProductsComponent],
  templateUrl: './master-products.html',
  styleUrls: ['./master-products.css'],
})
export class MasterProducts {
  selectedCatId: number = 0;
  grandTotal:    number = 0;
  cartCount:     number = 0;

  catList: ICategory[] = [
    { id: 0, name: 'All Pieces' },
    { id: 1, name: 'Elec' },
    { id: 2, name: 'Laptops' },
    { id: 3, name: 'Gpu' },
    { id: 4, name: 'Cpu' },
  ];

  /** Called when user buys a product — receives new running total from child */
  receiveTotal(newTotal: number) {
    this.grandTotal = newTotal;
    this.cartCount += 1;
  }

  /** Called when user cancels a product — receives the price to refund */
  receiveCancelPrice(price: number) {
    this.grandTotal -= price;
    this.cartCount  -= 1;
    if (this.grandTotal < 0) this.grandTotal = 0;
    if (this.cartCount  < 0) this.cartCount  = 0;
  }

  selectCategory(id: number) {
    this.selectedCatId = id;
  }
}
