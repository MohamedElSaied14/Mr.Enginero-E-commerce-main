import { Pipe, PipeTransform } from '@angular/core';

@Pipe
(
  { name: 'calc',
   standalone: true }
)
export class CalcPipe implements PipeTransform {
  transform(value: number, rate: number = 1): string { // input (): output
    return 'EGP ' + (value * rate).toLocaleString('en-EG', { minimumFractionDigits: 2 });
  }
}